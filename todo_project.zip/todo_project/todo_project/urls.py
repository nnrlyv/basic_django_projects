from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from tasks import views as task_views, views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', task_views.register_view, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='tasks/login.html'), name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('', include('tasks.urls')),
]
